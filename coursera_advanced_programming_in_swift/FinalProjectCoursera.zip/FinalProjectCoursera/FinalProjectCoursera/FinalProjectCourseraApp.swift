//
//  FinalProjectCourseraApp.swift
//  FinalProjectCoursera
//
//  Created by Zoltan Vegh on 21/07/2025.
//

import SwiftUI

@main
struct FinalProjectCourseraApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
