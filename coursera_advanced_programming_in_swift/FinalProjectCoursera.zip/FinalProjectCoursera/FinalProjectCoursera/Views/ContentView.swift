//
//  ContentView.swift
//  FinalProjectCoursera
//
//  Created by Zoltan Vegh on 21/07/2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        MenuItemsView()
    }
}

#Preview {
    ContentView()
}
