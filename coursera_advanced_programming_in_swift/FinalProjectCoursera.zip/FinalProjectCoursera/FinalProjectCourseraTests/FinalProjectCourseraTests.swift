//
//  FinalProjectCourseraTests.swift
//  FinalProjectCourseraTests
//
//  Created by Zoltan Vegh on 24/07/2025.
//

import Testing

struct FinalProjectCourseraTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
